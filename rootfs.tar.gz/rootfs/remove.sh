rmmod beep_driver.ko
rmmod led_driver.ko
rmmod motor_driver.ko
rmmod fan_driver.ko
rmmod m74hc595_driver.ko
rmmod si7006_driver.ko
