insmod beep_driver.ko
insmod led_driver.ko
insmod motor_driver.ko
insmod fan_driver.ko
insmod m74hc595_driver.ko
insmod si7006_driver.ko
